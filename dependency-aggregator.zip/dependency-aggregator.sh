#!/bin/bash

cloneRepository() {
    local target_directory=$1
    local repo_name=$2

    echo "Checking for composer.json file in $target_directory for $repo_name"

    if [ -e "$target_directory/composer.json" ] || [ -e "$target_directory/package.json" ]; then
        echo "$repo_name is already cloned in $target_directory. Skipping clone."
        return 0
    fi

    git clone "git@github.com:$repo_name.git"
}

extractComposerDependencies() {
    local directory="$1"
    local product="$2"

    jq -r ".[\"packages\"] | to_entries[] | .value.name as \$name | (.value.license | join(\",\")) as \$license | .value.version as \$version | \"\(\$name);\(\$version);composer;$product;require;\(\$license);\"" "$directory/composer.lock" >> "$directory/aggregated-dependency.csv"
    jq -r ".[\"packages-dev\"] | to_entries[] | .value.name as \$name | (.value.license | join(\",\")) as \$license | .value.version as \$version | \"\(\$name);\(\$version);composer;$product;require-dev;\(\$license);\"" "$directory/composer.lock" >> "$directory/aggregated-dependency.csv"
}

extractPackageDependencies() {
    local directory="$1"
    local product="$2"

echo "      Aggregating package-lock.json files in $directory"

   # package-lock.json in node_module directories are redundant
   # the first key in the "packages" array is always empty string "" and contains the constraints, no realised dependencies
   # a few packages define the "name" attribute, which serves as primary package name when searching the node repository
   # some Spryker packages are not accessible in the node repository, have no license information and only their key contains the "Spryker" keyword
   # packages are installed in multiple versions
   # packages with "link:true" are serving as simlink to the real packages, thus we skip the linked item
   find "$directory" -name 'package-lock.json' -not -path '*/node_modules/*' -exec jq -r ".packages | to_entries[] | .key as \$key | select(.key != \"\") | select(.value | has(\"dev\")) | select(.value | has(\"link\") | not or (.link != true)) |.value | has(\"resolved\") as \$resolved | (.name // \$key) as \$keyfinal | .version as \$v | \"\(\$keyfinal);\(\$v);npm;$product;require-dev;;\"" {} + 2>/dev/null | sort | uniq >> "$directory/aggregated-dependency.csv"
   find "$directory" -name 'package-lock.json' -not -path '*/node_modules/*' -exec jq -r ".packages | to_entries[] | .key as \$key | select(.key != \"\") | select(.value | has(\"dev\") | not) | select(.value | has(\"link\") | not or (.link != true)) | .value | has(\"resolved\") as \$resolved | (.name // \$key) as \$keyfinal | .version as \$v | \"\(\$keyfinal);\(\$v);npm;$product;require;;\"" {} + 2>/dev/null | sort | uniq >> "$directory/aggregated-dependency.csv"

   # compensating package-lock's dependency keying. The dependency of "A" is keyed as "node_modules/A/node_modules/A-dependency-1"
   awk -F';' '{sub(/.*node_modules\//, "", $1); print $1 ";" $2 ";" $3 ";" $4 ";" $5 ";" $6 }' "$directory/aggregated-dependency.csv" > "$directory/temp-aggregated-dependency.csv"
   mv "$directory/temp-aggregated-dependency.csv" "$directory/aggregated-dependency.csv"
}

installComposer() {
  local target_directory=$1

  (cd "$target_directory" && composer install --ignore-platform-reqs && cd ..)
}

populateLicenseCache() {
  local aggregated_dependencies=$1
  local license_cache_file=$2

  awk -F';' '$3 == "npm" {print $1 ";" $2}' "$aggregated_dependencies" | sort | uniq > "license_requirement.temp"

  if [ ! -f "$license_cache_file" ]; then
      echo "{}" > "$license_cache_file"
  fi

  # special packages that use alias and have no sign of being Spryker, neither can be found on npm registry
  sprykerpackages=(
      "mp-dashboard"
      "mp-gui-table"
      "mp-login"
      "mp-product-list"
      "mp-product-offer"
      "mp-profile"
      "mp-sales-orders"
      "mp-user"
      "mp-zed-ui"
  )

  max_cycles=7000
  cycle_count=0
  while IFS=';' read -r package version; do
      ((cycle_count++))

      if [ "$cycle_count" -gt "$max_cycles" ]; then
          echo "Preemptive measure: max cycles reached - exiting loop."
          break
      fi

      # if we store latest version in the cache, it will get outdated naturally
      if [[ "$version" == "latest" || "$version" == "*" || "$version" == "master" || "$version" == "dev-master" ]]; then
          continue;
      fi

      # Check if the package version is already in the cache
      if jq -e --arg pkg "$package" --arg ver "$version" '.[$pkg][$ver] != null' "$license_cache_file" >/dev/null; then
          echo "$cycle_count package $package-$version found in cache."
      else
          echo "$cycle_count package $package-$version not found in cache. Fetching license info from npm registry (https://registry.npmjs.org/$package/$version)..."

          echo ""

          # If the package contains "spryker" string or can be found in the sprykerpackages array
          if [[ "$package" == *spryker* || " ${sprykerpackages[@]} " =~ " $package " ]]; then
              license="spryker"
          else
              temp=$(curl -s "https://registry.npmjs.org/$package/$version" | jq -r '"\(.version);\(.license)"')
              temp=$(curl -s "https://registry.npmjs.org/$package/$version" | jq -r '
                # Define a function to flatten the "license" key
                def flatten_license:
                  if type == "string" then
                    .   # If "license" is already a string, return it as is
                  elif type == "array" then
                    . | map(tostring) | join(", ")   # Convert each element to a string and join them with a comma
                  elif type == "object" then
                    . | to_entries | map("\(.value)") | join(", ")   # Convert each key-value pair to a string and join them with a comma
                  else
                    empty   # If "license" is neither a string, an array, nor an object, return empty
                  end;

                # Flatten the "license" key and output the result along with the version
                "\(.version);\(.license | flatten_license)"
              ')
              IFS=';' read -r version_unused license <<< "$temp"
              if [[ -z "$license" || "$license" == "null" ]]; then
                license="no-license"
              fi
          fi

          echo "Adding $package-$version to cache with license info: $license"
          jq --arg pkg "$package" --arg ver "$version" --arg lic "$license" \
             '.[$pkg] |= . + { ($ver): $lic }' "$license_cache_file" > temp && mv temp "$license_cache_file"
      fi
  done < "license_requirement.temp"

  rm -f "license_requirement.temp"
}

disclaimer() {
    if ! command -v jq &> /dev/null; then
        echo "The 'jq' package is required for running this command. Please install it before proceeding: brew install jq."
        exit 1
    fi

    if ! command -v python3 &>/dev/null && ! command -v python &>/dev/null; then
        echo "Python is required for running this command. Please install it before proceeding."
        exit 1
    fi

    if ! [ -e "dependency-license-cache.json" ]; then
      read -p "This command will download all FE license information (~5000 packages). It is recommended to download the dependency-license-cache.json in the working directory to leverage the time and network usage. Still continue without cache? [y/n]: " choice
      case "$choice" in
          y|Y ) return 0 ;;
          n|N ) echo "Operation cancelled"; exit 0 ;;
          * ) echo "Invalid input. Please enter 'y' or 'n'."; disclaimer ;;
      esac
    fi

    read -p "This command will clone repositories, install their dependencies to your current directory. Do you want to proceed? [y/n]: " choice
    case "$choice" in
        y|Y ) return 0 ;;
        n|N ) echo "Operation cancelled"; exit 0 ;;
        * ) echo "Invalid input. Please enter 'y' or 'n'."; disclaimer ;;
    esac
}

# Processing CLI arguments
composer_install=true
aggregate=true
help=false
license_cache_generation=true
while [[ $# -gt 0 ]]; do
    key="$1"
    case $key in
        --no-composer-install)
            composer_install=false
            shift
            ;;
        --no-aggregation)
            aggregate=false
            shift
            ;;
        --no-cache-generation)
            license_cache_generation=false
            shift
            ;;
        --help)
            help=true
            shift
            ;;
        *)
            shift
            ;;
    esac
done

if $help; then
  echo ""
  echo "Usage: dependency-aggregator.sh [--no-composer-install] [--no-aggregation] [--no-cache-generation]"
  echo ""
  echo "The command clones Spryker products to local directory, then installs composer dependencies, then gathers all realised composer and package dependencies to a file. Due npm package license information is only available online, it is recommended to prepare a license cache (see tool documentation) to avoid huge network access to npm registry."
  echo ""
  echo "All of the below arguments are created for debugging purposes where you repeatedly need to run the command and want to skip some parts:"
  echo "  --no-composer-install If composer is already installed in each product repository, you can skip it via this argument."
  echo "  --no-aggregation      If the composer and package dependency were already aggregated recently, you can skip their aggregation via this argument."
  echo "  --no-cache-generation If the cache is already up-to-date, you can skip the generation via this argument."
  echo ""

  exit
fi


echo ""
disclaimer

echo ""
echo "1/8 - Cloning repositories"

cloneRepository "b2b-demo-marketplace" "spryker-shop/b2c-demo-marketplace"
cloneRepository "b2c-demo-marketplace" "spryker-shop/b2b-demo-marketplace"
cloneRepository "b2c-demo-shop" "spryker-shop/b2c-demo-shop"
cloneRepository "b2b-demo-shop" "spryker-shop/b2b-demo-shop"
cloneRepository "suite" "spryker-shop/suite"
cloneRepository "oryx" "spryker/oryx"

echo ""
echo "2/8 - Installing composer dependencies"
if $composer_install; then
  installComposer "b2b-demo-marketplace"
  installComposer "b2c-demo-marketplace"
  installComposer "b2c-demo-shop"
  installComposer "b2b-demo-shop"
  installComposer "suite"
else
  echo "Skipping composer install due --no-composer-install argument."
fi

echo ""
echo "3/8 - Removing previously aggregated dependencies (NOT touching license cache)"
if $aggregate; then
  rm -f "b2b-demo-marketplace/aggregated-dependency.csv"
  rm -f "b2c-demo-marketplace/aggregated-dependency.csv"
  rm -f "b2b-demo-shop/aggregated-dependency.csv"
  rm -f "b2c-demo-shop/aggregated-dependency.csv"
  rm -f "suite/aggregated-dependency.csv"
  rm -f "oryx/aggregated-dependency.csv"
else
  echo "Skipping removal due --no-aggregation argument."
fi

echo ""
echo "4/8 - Aggregating composer.lock dependencies"
if $aggregate; then
  extractComposerDependencies "b2b-demo-marketplace" "B2B MP"
  extractComposerDependencies "b2c-demo-marketplace" "B2C MP"
  extractComposerDependencies "b2b-demo-shop" "B2B"
  extractComposerDependencies "b2c-demo-shop" "B2C"
  extractComposerDependencies "suite" "suite"
else
  echo "Skipping aggregation due --no-aggregation argument."
fi

echo ""
echo "5/8 - Aggregating package-lock.json dependencies"
if $aggregate; then
  extractPackageDependencies "b2b-demo-marketplace" "B2B MP"
  extractPackageDependencies "b2c-demo-marketplace" "B2C MP"
  extractPackageDependencies "b2b-demo-shop" "B2B"
  extractPackageDependencies "b2c-demo-shop" "B2C"
  extractPackageDependencies "suite" "suite"
  extractPackageDependencies "oryx" "oryx"
else
  echo "Skipping aggregation due --no-aggregation argument."
fi

echo ""
echo "6/8 - Merging composer and package dependencies from all products"
cat "b2b-demo-marketplace/aggregated-dependency.csv" "b2c-demo-marketplace/aggregated-dependency.csv" "b2c-demo-shop/aggregated-dependency.csv" "b2b-demo-shop/aggregated-dependency.csv" "oryx/aggregated-dependency.csv" "suite/aggregated-dependency.csv"| sort | uniq | sed '/^$/d' > "aggregated-dependency.csv"


echo ""
echo "7/8 - Retrieving FE licenses (preferring cache first)"
if $license_cache_generation; then
  populateLicenseCache "aggregated-dependency.csv" "dependency-license-cache.json"
else
  echo "Skipping license cache generation due --no-cache-generation."
fi
python3 dependency-aggregator.py --attach-license

echo ""
echo "8/8 - Formatting results"
python3 dependency-aggregator.py --format-dependency
python3 dependency-aggregator.py --render csv
python3 dependency-aggregator.py --render md


