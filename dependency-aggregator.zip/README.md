# Guide

1. Move dependency-aggregator.sh, dependency-aggregator.py, and dependency-license-cache.json to a new, untracked, empty, temp directory
2. Run dependency-aggregator.sh (it will clone all products, and install their dependencies, and generate dependency-overviews)
3. Copy and release the dependency-overview.md into spryker-shop/suite root directory.
4. Update the dependency-license-cache.json in its origin if it was changed.
