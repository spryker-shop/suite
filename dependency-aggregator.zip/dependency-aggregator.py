import csv
import json
import sys
import shutil

def attach_license():
    license_cache = "dependency-license-cache.json"
    aggregated_dependency = "aggregated-dependency.csv"
    aggregated_dependency_temp = "aggregated-dependency.temp"

    with open(license_cache, 'r') as cache_file:
        cache_data = json.load(cache_file)

    with open(aggregated_dependency, 'r') as csv_file, open(aggregated_dependency_temp, 'w', newline='') as target_file:
        csv_reader = csv.reader(csv_file, delimiter=';')
        csv_writer = csv.writer(target_file, delimiter=';')

        for row in csv_reader:
            if row[2] == "composer":
                csv_writer.writerow(row)
            elif row[2] == "npm":
                # license column
                if row[5]:
                    csv_writer.writerow(row)
                else:
                    # Check cache for license information
                    package = row[0]
                    version = row[1]
                    if package in cache_data and version in cache_data[package]:
                        row[5] = cache_data[package][version]
                        csv_writer.writerow(row)
                    else:
                        # TBD: "latest", "*", "master", "dev-master" can not be stored in cache (due natural outdating) - no FE use-case atm
                        print(f"Error: License information for package {package} version {version} not found in cache.")
                        sys.exit(1)
            else:
                print("Error: Invalid value in 3rd column. Must be 'composer' or 'npm'.")
                sys.exit(1)

    shutil.move(aggregated_dependency_temp, aggregated_dependency)


def format_dependency():
    csv_file = "aggregated-dependency.csv"
    json_file = "dependency-overview.json"

    data = {}
    with open(csv_file, newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile, delimiter=';')
        for row in reader:
            package_name = row[0]
            package_version = row[1]
            package_manager = row[2]
            product_name = row[3]
            dependency_type = row[4]
            license_type = row[5]

            if package_name not in data:
                data[package_name] = {
                    "licenses": [],
                    "package manager": package_manager,
                    "dependency type": [],
                }

            # Append license type
            if license_type not in data[package_name]["licenses"]:
                data[package_name]["licenses"].append(license_type)

            # Append dependency type
            if dependency_type not in data[package_name]["dependency type"]:
                data[package_name]["dependency type"].append(dependency_type)

            # Append product version
            if product_name not in data[package_name]:
                data[package_name][product_name] = []
            if package_version not in data[package_name][product_name]:
                data[package_name][product_name].append(package_version)

    # Write data to JSON file
    with open(json_file, 'w') as outfile:
        json.dump(data, outfile, indent=4)

    print("JSON file generated successfully.")


def render(format):
    if format == "md":
        json_file = "dependency-overview.json"
        md_file = "dependency-overview.md"

        with open(md_file, "w") as md:
            md.write("| Package Name | Licenses | Package Manager | Dependency types | suite | B2C | B2B | B2C MP | B2B MP | Oryx |\n")
            md.write("| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |\n")

        # Read JSON file and write data to markdown file
        with open(json_file, "r") as jf, open(md_file, "a") as md:
            data = json.load(jf)
            for package, info in data.items():
                licenses = ", ".join(info.get("licenses", ["n/a"]))
                package_manager = info.get("package manager", "n/a")
                dependency_types = ", ".join(info.get("dependency type", ["n/a"]))
                suite = ", ".join(info.get("suite", ["n/a"]))
                b2c = ", ".join(info.get("B2C", ["n/a"]))
                b2b = ", ".join(info.get("B2B", ["n/a"]))
                b2c_mp = ", ".join(info.get("B2C MP", ["n/a"]))
                b2b_mp = ", ".join(info.get("B2B MP", ["n/a"]))
                oryx = ", ".join(info.get("oryx", ["n/a"]))
                md.write(f"| {package} | {licenses} | {package_manager} | {dependency_types} | {suite} | {b2c} | {b2b} | {b2c_mp} | {b2b_mp} | {oryx} |\n")

        print("Markdown file generated successfully.")
    if format == "csv":
        json_file = "dependency-overview.json"
        csv_file = "dependency-overview.csv"

        with open(json_file, 'r') as f:
            data = json.load(f)

        with open(csv_file, 'w', newline='') as f:
            writer = csv.writer(f, delimiter=';')

            writer.writerow(["Package Name", "Licenses", "Package Manager", "Dependency types", "suite", "B2C", "B2B", "B2C MP", "B2B MP", "Oryx"])

            for package, info in data.items():
                licenses = ', '.join(info.get('licenses', ['n/a']))
                package_manager = info.get('package manager', 'n/a')
                dependency_types = ', '.join(info.get('dependency type', ['n/a']))
                suite = ', '.join(info.get('suite', ['n/a']))
                b2c = ', '.join(info.get('B2C', ['n/a']))
                b2b = ', '.join(info.get('B2B', ['n/a']))
                b2c_mp = ', '.join(info.get('B2C MP', ['n/a']))
                b2b_mp = ', '.join(info.get('B2B MP', ['n/a']))
                oryx = ', '.join(info.get('oryx', ['n/a']))

                writer.writerow([package, licenses, package_manager, dependency_types, suite, b2c, b2b, b2c_mp, b2b_mp, oryx])

        print("CSV file generated successfully.")


def main():
    if len(sys.argv) < 2:
        print("Usage: python dependency-aggregator.py --attach-license / --format-dependency / --render [md/csv]")
        sys.exit(1)

    arg = sys.argv[1]
    if arg == "--attach-license":
        attach_license()
    elif arg == "--format-dependency":
        format_dependency()
    elif arg == "--render":
        if len(sys.argv) > 2:
            render_format = sys.argv[2].lower()  # Extract and convert the format to lowercase
            if render_format in ['md', 'csv']:
                render(render_format)
            elif render_format in ['.md', '.csv']:
                render_format = render_format[1:]
                render(render_format)
            else:
                print("Invalid format. Please specify 'md' or 'csv'.")
                sys.exit(1)
        else:
            print("Usage: python dependency-aggregator.py --render [md/csv]")
            sys.exit(1)
    else:
        print("Usage: python dependency-aggregator.py --attach-license / --format-dependency / --render [md/csv]")
        sys.exit(1)

if __name__ == "__main__":
    main()
